# LAWSTART: загрузка страниц catalog.html и legal-english.html (этап 1)

В архиве ВСЕ файлы лежат в одной папке, без подпапок, чтобы их можно было загрузить с телефона. index.html в архиве НЕТ — текущую главную менять не нужно.

## Файлы для загрузки в корень репозитория (24 файла, кроме этой инструкции)
- Страницы: catalog.html, legal-english.html
- Стили и скрипты: lawstart.css, lawstart-nav.js, lawstart-catalog.js, lawstart-legal-english.js
- Картинки: lawstart-img-catalog-01.jpg, lawstart-img-legal-english-01.jpg … -13.jpg (14 файлов)
- Служебные: robots.txt, sitemap.xml, og.jpg, favicon.svg
README_UPLOAD_RU.md загружать не нужно.

## Как загрузить с Android
1. Скачайте lawstart-multipage-stage1.zip и распакуйте (Files by Google: нажать на архив → «Извлечь»).
2. Откройте в браузере (Chrome) https://github.com/Lawstartkz/lawstartkz.github.io, войдите в аккаунт. Если открывается мобильная версия, в меню браузера включите «Версия для ПК».
3. Add file → Upload files.
4. Нажмите «choose your files», откройте распакованную папку, выделите все файлы КРОМЕ README_UPLOAD_RU.md (долгое нажатие, затем выбор остальных), подтвердите.
5. Дождитесь загрузки всех 24 файлов в списке. Если на экране виден файл с именем index.html — уберите его.
6. В поле Commit message напишите, например: «Add catalog and Legal English pages», выберите «Commit directly to the main branch», нажмите Commit changes.
7. Подождите несколько минут (вкладка Actions: зелёная отметка у последнего запуска) и откройте:
   https://lawstartkz.github.io/catalog.html
   https://lawstartkz.github.io/legal-english.html
   https://lawstartkz.github.io/robots.txt
   https://lawstartkz.github.io/sitemap.xml
   https://lawstartkz.github.io/og.jpg
8. Сообщите мне результат: открылись ли страницы, видны ли картинки, работают ли поиск в каталоге и словарь.

Если новые файлы не открываются (404) или в Actions красный запуск — ничего не удаляйте, пришлите скриншот.

## Потенциально конфликтующие файлы и то, что пока НЕЛЬЗЯ делать
- В репозитории два workflow: .github/workflows/static.yml и jekyll-gh-pages.yml. Оба запускаются при каждой загрузке и конкурируют за публикацию. Пока НИЧЕГО не удаляйте и не меняйте: сначала загрузите страницы и проверьте. Какой workflow оставить, решим после проверки (я рекомендую static.yml).
- Старые копии главной (index (2).html, index (3).html, index-2026-10-13-v4.html … index-2026-10-14-v8.html) не трогайте, не удаляйте и не переименовывайте. Они остаются публичными; решение по ним — отдельным шагом.
- Не загружайте index.html из других архивов и не заменяйте текущий.
- Если при загрузке GitHub пишет, что файл с таким именем уже существует (например robots.txt, sitemap.xml), не заменяйте его, а пришлите мне скриншот. В репозитории на момент проверки этих файлов не было.
- Не меняйте настройки Pages (Settings → Pages) и не включайте и не отключайте Jekyll.
- Папку data/ и файлы сообщества (export-qa) в этот набор не входят; их не загружайте.
- Главную страницу ссылками на новые страницы пока не обновляйте: это необязательный отдельный шаг.
